<?php

/**
 * Social Media
 *
 * Copyright 2019 by Oene Tjeerd de Bruin <oenetjeerd@sterc.nl>
 */

require_once dirname(__DIR__) . '/socialmediacriteria.class.php';

class SocialMediaCriteria_mysql extends SocialMediaCriteria
{
}
