<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'readme' => '----------------------
Social Media
----------------------
Version: 2.0.2
Author: Oene Tjeerd de Bruin
Contact: oenetjeerd@sterc.nl
----------------------
',
    'changelog' => '----------------------
Social Media
----------------------

----------------------
Version: 2.0.2
Released: 2019-05-13
----------------------
- Get likes and comments from API\'s

----------------------
Version: 2.0.1
Released: 2019-04-11
----------------------
- Some code clean ups
- You can filter social media messages on client side (NOT API SIDE).

----------------------
Version: 2.0.0
Released: 2019-03-25
----------------------
- Some parts refactored
- Criteria to import social media messages added
- API\'s fixed

----------------------
Version: 1.2.1
Released: 2017-09-20
----------------------
- Some bugfixes
- Small ExtJS fixes
- Github issues
    - Issue #9 fixed

----------------------
Version: 1.2.0
Released: 2017-08-31
----------------------
- Some bugfixes
- Github issues
    - Issue #7 fixed
    - Issue #8 fixed

----------------------
Version: 1.1.1
Released: 2017-06-23
----------------------
- Some bugfixes
- Github issues
    - Issue #1 fixed
    - Issue #2 fixed
    - Issue #3 fixed
    - Issue #4 fixed

----------------------
Version: 1.1.0
Released: 2017-05-02
----------------------
- Some bugfixes
- New social media channels
    - Facebook support
    - LinkedIn support
    - Pinterest support
    - Youtube support

----------------------
Version: 1.0.0
Released: 2016-09-20
----------------------
- First release
    - Twitter support
    - Instagram support',
    'setup-options' => 'socialmedia-2.0.2-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '9dcec9fd3d470a033f50a8a21a98679f',
      'native_key' => 'socialmedia',
      'filename' => 'modNamespace/d77bcc023059aa371fbd7ca32cfa5e60.vehicle',
      'namespace' => 'socialmedia',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ca575046fa7dcc415d14784c61baf91',
      'native_key' => 'socialmedia.branding_url',
      'filename' => 'modSystemSetting/c63d5dfb7b4052d2c1775527583be9a3.vehicle',
      'namespace' => 'socialmedia',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8065926f493ee0df3757bfdfaace57b8',
      'native_key' => 'socialmedia.branding_url_help',
      'filename' => 'modSystemSetting/1c20df3d3ffe0a9b47650f90626f4c1c.vehicle',
      'namespace' => 'socialmedia',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1bd2673667bf196023b693caf81f1e55',
      'native_key' => 'socialmedia.cronjob',
      'filename' => 'modSystemSetting/06ef1bac697d11bd2c07946a0e93cbec.vehicle',
      'namespace' => 'socialmedia',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '392e3e54f142583a66e60a3d03a11b0b',
      'native_key' => 'socialmedia.remove_emoji',
      'filename' => 'modSystemSetting/f554224bdb3cdcac06f6d8f977d8d593.vehicle',
      'namespace' => 'socialmedia',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '78c3cf4c9a3d957958c3cf89897739d7',
      'native_key' => 'socialmedia.cronjob_hash',
      'filename' => 'modSystemSetting/a369f9086d42f9d4193a4f1f6cb8c2a8.vehicle',
      'namespace' => 'socialmedia',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aba546980ac410653e3ce56d71d2f27e',
      'native_key' => 'socialmedia.default_active',
      'filename' => 'modSystemSetting/2feffcbbd3b4a14f2e4edffdefe6ff4d.vehicle',
      'namespace' => 'socialmedia',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46093a9e939f04aa8013f7d89d81f092',
      'native_key' => 'socialmedia.log_email',
      'filename' => 'modSystemSetting/95453095f6a071be728c87d9462ed3b1.vehicle',
      'namespace' => 'socialmedia',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7768153644eaa29f046a178f67cf48b0',
      'native_key' => 'socialmedia.log_lifetime',
      'filename' => 'modSystemSetting/6da5977ef1c4139f613e75da159acc84.vehicle',
      'namespace' => 'socialmedia',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e1b01846ddd05be6331a89412919ed4',
      'native_key' => 'socialmedia.log_send',
      'filename' => 'modSystemSetting/3516ddca6f612674af9fec772a02a304.vehicle',
      'namespace' => 'socialmedia',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8782a3255d97155ebc0724c6fe4e83db',
      'native_key' => 'socialmedia.source_facebook_access_token',
      'filename' => 'modSystemSetting/811dd3a899cefd73161ea789855ccc39.vehicle',
      'namespace' => 'socialmedia',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd46eb8f91986704d5c2697ae908dea39',
      'native_key' => 'socialmedia.source_facebook_client_id',
      'filename' => 'modSystemSetting/56eca82953455f55fabc27dc6c999fe2.vehicle',
      'namespace' => 'socialmedia',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f4891ad245ea1b0a5e76205391493710',
      'native_key' => 'socialmedia.source_facebook_client_secret',
      'filename' => 'modSystemSetting/597eedc2952666532d7cbb549429fa04.vehicle',
      'namespace' => 'socialmedia',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e2e883627f4fa5db933b6ad1c594dd2',
      'native_key' => 'socialmedia.source_facebook_empty_posts',
      'filename' => 'modSystemSetting/e3bc94968adc2a712e57d222d2fc3a27.vehicle',
      'namespace' => 'socialmedia',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51405a7bbd9f6d6f9e413285d3a20905',
      'native_key' => 'socialmedia.source_instagram_access_token',
      'filename' => 'modSystemSetting/0c6c57b6db8b82ae1fed5d5890b18874.vehicle',
      'namespace' => 'socialmedia',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ab44fbc02a06035aa6b06765344da69',
      'native_key' => 'socialmedia.source_instagram_client_id',
      'filename' => 'modSystemSetting/684f7bbcd761035d30319fc496409126.vehicle',
      'namespace' => 'socialmedia',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e93bbe5af3bddf0a5c77832bc2134b01',
      'native_key' => 'socialmedia.source_instagram_client_secret',
      'filename' => 'modSystemSetting/4f00d465e394749512872ff4b0d6b152.vehicle',
      'namespace' => 'socialmedia',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b94906b37d8d88d73ae4ef1f5b1725a',
      'native_key' => 'socialmedia.source_instagram_empty_posts',
      'filename' => 'modSystemSetting/cc355ae1c960d8e2f1a4c7abb588c541.vehicle',
      'namespace' => 'socialmedia',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '76b657129243897ddcc796ddc3a62fc3',
      'native_key' => 'socialmedia.source_linkedin_access_token',
      'filename' => 'modSystemSetting/c2be98fd205eb220c51174ccb825ab3d.vehicle',
      'namespace' => 'socialmedia',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a3f1ce7211fcfdec1b7d87285298102',
      'native_key' => 'socialmedia.source_linkedin_client_id',
      'filename' => 'modSystemSetting/adefac53870f245bc30515c3fc356f1e.vehicle',
      'namespace' => 'socialmedia',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6a633abeb000a0aa01aadeef3c7b2440',
      'native_key' => 'socialmedia.source_linkedin_client_secret',
      'filename' => 'modSystemSetting/8be505c29e43d02c60a5ecaeb92f5de4.vehicle',
      'namespace' => 'socialmedia',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8268f6693d1fd8968c5cc91af41f4a25',
      'native_key' => 'socialmedia.source_linkedin_empty_posts',
      'filename' => 'modSystemSetting/bef0d968e830f846486f8a3bc04774aa.vehicle',
      'namespace' => 'socialmedia',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '59c419640d5064774bbd6521f0c159d4',
      'native_key' => 'socialmedia.source_pinterest_access_token',
      'filename' => 'modSystemSetting/1bb4452d53cebd8fa7f699795c3198ba.vehicle',
      'namespace' => 'socialmedia',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cb2ee57a017bc6cd5a1728a08b5de819',
      'native_key' => 'socialmedia.source_pinterest_client_id',
      'filename' => 'modSystemSetting/304b6c242fa05fea499f48245facab3d.vehicle',
      'namespace' => 'socialmedia',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '982e439fd26bd897978e5a50800bad1d',
      'native_key' => 'socialmedia.source_pinterest_client_secret',
      'filename' => 'modSystemSetting/b4b642960fb9a90a93874f918e117a10.vehicle',
      'namespace' => 'socialmedia',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '01332a9e20edb67a29b985997db05d34',
      'native_key' => 'socialmedia.source_pinterest_empty_posts',
      'filename' => 'modSystemSetting/689c47a12075a6b5d8f8d74ae936952d.vehicle',
      'namespace' => 'socialmedia',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4fbf72bdea0dedbd873fafd385a7f0f6',
      'native_key' => 'socialmedia.source_twitter_access_token',
      'filename' => 'modSystemSetting/c199d70d4dab2310e0173f98c2eea621.vehicle',
      'namespace' => 'socialmedia',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e02a0e019e11b692e269321892b6d062',
      'native_key' => 'socialmedia.source_twitter_access_token_secret',
      'filename' => 'modSystemSetting/ebc6c2a100510f7853e6e68ada7f1b84.vehicle',
      'namespace' => 'socialmedia',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '687ee14468c2486d6e5d21d5657830bc',
      'native_key' => 'socialmedia.source_twitter_consumer_key',
      'filename' => 'modSystemSetting/d8c4c03692c61b027db6b71b9d8ac6f3.vehicle',
      'namespace' => 'socialmedia',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ed735160457e3c880bed41b4e9d085f',
      'native_key' => 'socialmedia.source_twitter_consumer_key_secret',
      'filename' => 'modSystemSetting/cd44d9fe222cf29932846a60d6a2b084.vehicle',
      'namespace' => 'socialmedia',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2ee8b52befa861d0fd08f63c4d7e1f9',
      'native_key' => 'socialmedia.source_twitter_empty_posts',
      'filename' => 'modSystemSetting/cefeb9be7f6374db6536711d17e50481.vehicle',
      'namespace' => 'socialmedia',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd6f15a0077971ccf32c5f2c4973ffa0',
      'native_key' => 'socialmedia.source_youtube_client_id',
      'filename' => 'modSystemSetting/144d240f18ca27b1b0deb7885659e2c1.vehicle',
      'namespace' => 'socialmedia',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '26d8a8c0345cd78b859c9884661132b0',
      'native_key' => 'socialmedia.source_youtube_client_secret',
      'filename' => 'modSystemSetting/dd05394e24fe5302bb92ffd5817a4c19.vehicle',
      'namespace' => 'socialmedia',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd1c62320218aecfb1ee1f2cc68d63d2f',
      'native_key' => 'socialmedia.source_youtube_refresh_token',
      'filename' => 'modSystemSetting/00ffc81e605f4d4522296edb34b05cc9.vehicle',
      'namespace' => 'socialmedia',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '742b5fd7a038ff29ffdad034f816aa51',
      'native_key' => 'socialmedia.source_youtube_empty_posts',
      'filename' => 'modSystemSetting/f34546946e9b26ac213e7bd1e8361168.vehicle',
      'namespace' => 'socialmedia',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'd5bc1ac144f2207a3741146cbcc0e804',
      'native_key' => NULL,
      'filename' => 'modCategory/5c5d70faeab46d78ca1a46ad2f5a84e1.vehicle',
      'namespace' => 'socialmedia',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'c44aca4e4512496783c9913d10c07514',
      'native_key' => 'socialmedia',
      'filename' => 'modMenu/aeaed4a586c064d2e49eb1f3c1c70ab9.vehicle',
      'namespace' => 'socialmedia',
    ),
  ),
);