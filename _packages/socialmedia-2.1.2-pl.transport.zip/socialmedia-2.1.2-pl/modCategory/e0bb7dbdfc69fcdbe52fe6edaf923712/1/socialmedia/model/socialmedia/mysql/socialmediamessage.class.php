<?php

/**
 * Social Media
 *
 * Copyright 2019 by Oene Tjeerd de Bruin <oenetjeerd@sterc.nl>
 */

require_once dirname(__DIR__) . '/socialmediamessage.class.php';

class SocialMediaMessage_mysql extends SocialMediaMessage
{
}
