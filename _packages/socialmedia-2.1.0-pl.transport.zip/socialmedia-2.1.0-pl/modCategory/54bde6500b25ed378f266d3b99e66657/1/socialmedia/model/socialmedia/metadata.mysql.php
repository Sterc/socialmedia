<?php

/**
* Social Media
*
* Copyright 2019 by Oene Tjeerd de Bruin <oenetjeerd@sterc.nl>
*/

$xpdo_meta_map = [
    'xPDOSimpleObject' => [
        'SocialMediaMessage',
        'SocialMediaCriteria'
    ]
];
